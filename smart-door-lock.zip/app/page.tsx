"use client"

import  from "../static/js/metrics"

export default function SyntheticV0PageForDeployment() {
  return < />
}